# Android_App
지금까지 배운 내용을 이용해 어플 만듬

# 화면
## 메인화면
![image](https://user-images.githubusercontent.com/108244911/192427200-7b9dc7fa-45a9-4ad1-8e1f-d2ecc7e5fc04.png)

## 메뉴
![image](https://user-images.githubusercontent.com/108244911/192427299-24caaed3-a64c-4fea-ac2a-e9d6e20a0ba4.png)

## 스토리 시작
![image](https://user-images.githubusercontent.com/108244911/192427385-99bafed4-0b54-4378-bcb1-f2cb455601f3.png)

## 엔딩
![image](https://user-images.githubusercontent.com/108244911/192427436-00b6d41c-f26b-44f8-9bee-61f7a24ca885.png)
